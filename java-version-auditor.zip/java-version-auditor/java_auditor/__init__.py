"""Modular Java version auditor."""
