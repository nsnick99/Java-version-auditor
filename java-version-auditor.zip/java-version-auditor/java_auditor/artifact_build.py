"""Build type, packaging, Java version and application version detection."""

import re
import xml.etree.ElementTree as ET
from collections import Counter

from .classfile import major_to_java, parse_class, ClassFormatError

POM_NS = {"m": "http://maven.apache.org/POM/4.0.0"}


def parse_manifest(text):
    """Parse MANIFEST.MF into a dict (handles continuation lines)."""
    result, last = {}, None
    for line in text.splitlines():
        if line.startswith(" ") and last:
            result[last] += line[1:]
        elif ":" in line:
            key, _, val = line.partition(":")
            last = key.strip()
            result[last] = val.strip()
    return result


def _strip_ns(root):
    for el in root.iter():
        if "}" in el.tag:
            el.tag = el.tag.split("}", 1)[1]
    return root


def parse_pom(text):
    try:
        root = _strip_ns(ET.fromstring(text))
    except ET.ParseError:
        return None

    def find(path):
        el = root.find(path)
        return el.text.strip() if el is not None and el.text else None

    props = {}
    pe = root.find("properties")
    if pe is not None:
        for child in pe:
            props[child.tag] = (child.text or "").strip()

    def resolve(value):
        if value is None:
            return None
        m = re.fullmatch(r"\$\{(.+)\}", value)
        return props.get(m.group(1), value) if m else value

    deps = []
    for d in root.findall("./dependencies/dependency"):
        g = d.findtext("groupId", "").strip()
        a = d.findtext("artifactId", "").strip()
        v = resolve((d.findtext("version") or "").strip() or None)
        s = (d.findtext("scope") or "compile").strip()
        deps.append({"groupId": g, "artifactId": a, "version": v, "scope": s})

    parent = root.find("parent")
    parent_info = None
    if parent is not None:
        parent_info = {
            "groupId": parent.findtext("groupId", "").strip(),
            "artifactId": parent.findtext("artifactId", "").strip(),
            "version": parent.findtext("version", "").strip(),
        }

    plugins = root.findall(".//plugin/configuration")
    compiler_cfg = {}
    for plugin in root.findall(".//plugin"):
        if plugin.findtext("artifactId") == "maven-compiler-plugin":
            cfg = plugin.find("configuration")
            if cfg is not None:
                for key in ("source", "target", "release"):
                    val = cfg.findtext(key)
                    if val:
                        compiler_cfg[key] = resolve(val.strip())
    del plugins

    return {
        "groupId": find("groupId") or (parent_info or {}).get("groupId"),
        "artifactId": find("artifactId"),
        "version": find("version") or (parent_info or {}).get("version"),
        "packaging": find("packaging") or "jar",
        "name": find("name"),
        "parent": parent_info,
        "properties": props,
        "compiler": compiler_cfg,
        "dependencies": deps,
    }


GRADLE_DEP = re.compile(
    r"""(?P<conf>implementation|api|compileOnly|runtimeOnly|testImplementation|
        compile|runtime|testCompile|providedCompile)\s*\(?\s*['"]
        (?P<g>[^:'"]+):(?P<a>[^:'"]+)(?::(?P<v>[^'"]+))?['"]""",
    re.X,
)


def parse_gradle(text):
    deps = []
    for m in GRADLE_DEP.finditer(text):
        deps.append({
            "groupId": m.group("g"), "artifactId": m.group("a"),
            "version": m.group("v"), "scope": m.group("conf"),
        })
    compat = {}
    for key, pat in (
        ("source", r"sourceCompatibility\s*=\s*['\"]?([\w.]+)"),
        ("target", r"targetCompatibility\s*=\s*['\"]?([\w.]+)"),
        ("toolchain", r"languageVersion\s*(?:=|\.set\()\s*JavaLanguageVersion\.of\((\d+)\)"),
        ("jvmTarget", r"jvmTarget\s*=\s*['\"]?([\w.]+)"),
    ):
        m = re.search(pat, text)
        if m:
            compat[key] = m.group(1)
    plugins = re.findall(r"id\s*\(?['\"]([\w.\-]+)['\"]\)?(?:\s*version\s*['\"]([\w.\-]+)['\"])?", text)
    return {"dependencies": deps, "compatibility": compat,
            "plugins": [{"id": p, "version": v or None} for p, v in plugins]}


def detect_build(src):
    names = src.names()
    lower = {n.lower(): n for n in names}
    info = {"tool": "UNKNOWN", "toolVersion": None, "packaging": None,
            "detectedFrom": [], "declaredFiles": []}
    pom = gradle = None

    # Source-tree style files at any depth, but prefer the shallowest.
    def shallowest(suffix):
        hits = sorted((n for n in names if n.lower().endswith(suffix)), key=lambda x: x.count("/"))
        return hits[0] if hits else None

    pom_path = shallowest("pom.xml")
    gradle_path = shallowest("build.gradle") or shallowest("build.gradle.kts")
    ant_path = shallowest("build.xml")

    if pom_path:
        info["tool"] = "Maven"
        info["detectedFrom"].append(pom_path)
        pom = parse_pom(src.read_text(pom_path))
    elif gradle_path:
        info["tool"] = "Gradle"
        info["detectedFrom"].append(gradle_path)
        gradle = parse_gradle(src.read_text(gradle_path))
    elif ant_path:
        info["tool"] = "Ant"
        info["detectedFrom"].append(ant_path)

    # Binary hints: pom.properties inside META-INF/maven
    pomprops = [n for n in names if n.startswith("META-INF/maven/") and n.endswith("/pom.properties")]
    embedded_pom = [n for n in names if n.startswith("META-INF/maven/") and n.endswith("/pom.xml")]
    if info["tool"] == "UNKNOWN" and (pomprops or embedded_pom):
        info["tool"] = "Maven"
        info["detectedFrom"] += pomprops[:1] + embedded_pom[:1]
        if embedded_pom:
            pom = parse_pom(src.read_text(embedded_pom[0]))

    for wrapper, key in (("maven-wrapper.properties", "mavenWrapper"),
                         ("gradle-wrapper.properties", "gradleWrapper")):
        w = next((n for n in names if n.endswith(wrapper)), None)
        if w:
            text = src.read_text(w)
            m = re.search(r"distributionUrl=.*?(?:apache-maven|gradle)-([\d.]+)", text)
            if m:
                info["toolVersion"] = m.group(1)
                info["declaredFiles"].append(w)

    manifest = {}
    if "META-INF/MANIFEST.MF" in lower.values() or "META-INF/MANIFEST.MF" in names:
        manifest = parse_manifest(src.read_text("META-INF/MANIFEST.MF"))
    created_by = manifest.get("Created-By", "")
    built_by = manifest.get("Built-By")
    if info["tool"] == "UNKNOWN":
        if "Maven" in created_by or "Apache Maven" in manifest.get("Build-Tool", ""):
            info["tool"] = "Maven"
            info["detectedFrom"].append("META-INF/MANIFEST.MF")
        elif "Gradle" in created_by or "Gradle" in manifest.get("Build-Tool", ""):
            info["tool"] = "Gradle"
            info["detectedFrom"].append("META-INF/MANIFEST.MF")
        elif any(k in manifest for k in ("Ant-Version",)):
            info["tool"] = "Ant"
            info["detectedFrom"].append("META-INF/MANIFEST.MF")
    if info["toolVersion"] is None:
        m = re.search(r"Apache Maven ([\d.]+)", created_by) or re.search(r"Gradle ([\d.]+)", created_by)
        if m:
            info["toolVersion"] = m.group(1)
    if info["tool"] == "Ant" and manifest.get("Ant-Version"):
        info["toolVersion"] = manifest["Ant-Version"].replace("Apache Ant", "").strip()

    # packaging
    if pom:
        info["packaging"] = pom["packaging"]
    elif src.kind in ("JAR", "WAR", "EAR"):
        info["packaging"] = src.kind.lower()
    if any(n.startswith("BOOT-INF/") for n in names):
        info["springBootFatJar"] = True
    if any(n.startswith("WEB-INF/") for n in names) and info["packaging"] in (None, "jar"):
        info["packaging"] = "war"

    info["buildJdk"] = manifest.get("Build-Jdk-Spec") or manifest.get("Build-Jdk") or None
    info["createdBy"] = created_by or None
    info["builtBy"] = built_by
    return info, pom, gradle, manifest


def detect_java(src, pom, gradle, class_infos):
    declared = {}
    if pom:
        comp = pom["compiler"]
        props = pom["properties"]
        for key, prop in (("source", "maven.compiler.source"), ("target", "maven.compiler.target"),
                          ("release", "maven.compiler.release")):
            val = comp.get(key) or props.get(prop)
            if val:
                declared[key] = val
        if "java.version" in props:
            declared["javaVersionProperty"] = props["java.version"]
    if gradle:
        declared.update(gradle["compatibility"])

    majors = Counter(ci.major for ci in class_infos if ci.major)
    result = {
        "compiledMajorVersion": None, "compiledAs": None,
        "declared": declared or None, "mixedClassVersions": len(majors) > 1,
        "classVersionHistogram": None,
    }
    if majors:
        top = max(majors)
        result["compiledMajorVersion"] = top
        result["compiledAs"] = f"Java {major_to_java(top)}"
        result["classVersionHistogram"] = {f"Java {major_to_java(k)}": v for k, v in sorted(majors.items())}
    return result


def detect_app_version(manifest, pom, src):
    for key in ("Implementation-Version", "Bundle-Version", "Specification-Version"):
        if manifest.get(key):
            return manifest[key]
    if pom and pom.get("version"):
        return pom["version"]
    return None


def detect_app_name(manifest, pom, src_label):
    if pom and pom.get("artifactId"):
        return pom["artifactId"]
    for key in ("Implementation-Title", "Bundle-Name", "Bundle-SymbolicName"):
        if manifest.get(key):
            return manifest[key]
    base = src_label.rstrip("/").split("/")[-1]
    return re.sub(r"[-_.]?\d.*$", "", base.rsplit(".", 1)[0]) or base


def collect_classes(src, prefixes=("WEB-INF/classes/", "BOOT-INF/classes/", "")):
    """Parse every application .class file (skipping nested library jars)."""
    infos = []
    for name in src.names():
        if not name.endswith(".class") or name.endswith("module-info.class"):
            continue
        if name.startswith("META-INF/versions/"):
            continue
        try:
            infos.append((name, parse_class(src.read(name))))
        except (ClassFormatError, Exception):
            continue
    return infos
