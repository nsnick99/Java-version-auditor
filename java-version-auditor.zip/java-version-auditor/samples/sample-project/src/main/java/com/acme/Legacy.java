package com.acme;

import javax.servlet.http.HttpServlet;
import javax.xml.bind.JAXBContext;
import sun.misc.Unsafe;

public class Legacy extends HttpServlet {
    void run(Thread t) throws Exception {
        Thread.currentThread().stop();
        Integer i = new Integer(5);
        JAXBContext.newInstance(Legacy.class);
    }
    @Override protected void finalize() { }
}
